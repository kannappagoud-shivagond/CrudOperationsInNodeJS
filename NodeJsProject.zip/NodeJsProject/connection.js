const mysql = require('mysql2');
const express = require('express');
var app = express();
const bodyparser = require('body-parser');

app.use(bodyparser.json());

var mysqlConnection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'Kannu@1995',
    database: 'flightdb',
    multipleStatements: true
});

mysqlConnection.connect((err) => {
    if (!err)
        console.log('DB connection Successfull');
    else
        console.log('DB connection failed \n Error : ' + JSON.stringify(err, undefined, 2));
});

app.listen(3000, () => console.log('Express server is running at port no :3000'));


//Get all Flights
app.get('/flights', (req, res) => {
    mysqlConnection.query('SELECT * FROM flightdb', (err, rows, fields) => {
        if (!err)
            //console.log(rows[0].FlightNumber);
            res.send(rows);
        else
            console.log(err)
    })

});
//GET an Flights
app.get('/flights/:Number', (req, res) => {
    mysqlConnection.query('SELECT * FROM flightdb WHERE FlightNumber =?', [req.params.Number], (err, rows, fields) => {
        if (!err)
            //console.log(rows[0].FlightNumber);
            res.send(rows);
        else
            console.log(err)
    })

});

//Delete Flights
app.delete('/flights/:Number', (req, res) => {
    mysqlConnection.query('DELETE FROM  flightdb WHERE FlightNumber =?', [req.params.Number], (err, rows, fields) => {
        if (!err)
            //console.log(rows[0].FlightNumber);
            res.send('Deleted Sucessfully...');
        else
            console.log(err)
    })

});

//Insert 

app.post('/flights', function (req, res) {
    let flightdb = req.body;
    console.log(flightdb);
    if (!flightdb) {
        return res.status(400).send({ error: true, message: 'Please provide user' });
    }
    mysqlConnection.query("INSERT INTO flightdb SET ? ", flightdb, function (error, results, fields) {
        if (error) throw error;
        return res.send({ error: false, data: results, message: 'New user has been created successfully.' });
    });
});


//UPDATE

app.put('/flights', function (req, res){
    mysqlConnection.query("UPDATE `flightdb` SET `FlightName`=?,`AirportName`=?,`PassengerName`=? WHERE `FlightNumber`=?",
    [req.body.FlightName, req.body.AirportName,req.body.PassengerName, req.body.FlightNumber], function (err,results,fields){
        if(err) throw err;
        res.send(JSON.stringify(results));
        
    });
});




